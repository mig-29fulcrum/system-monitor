#include <dirent.h>
#include <unistd.h>
#include <sstream>
#include <string>
#include <vector>
#include <stdlib.h>
#include <unistd.h>
#include "linux_parser.h"

using std::stof;
using std::string;
using std::to_string;
using std::vector;

// DONE: An example of how to read data from the filesystem
string LinuxParser::OperatingSystem() {
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' ');
      std::replace(line.begin(), line.end(), '"', ' ');
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}

// DONE: An example of how to read data from the filesystem
string LinuxParser::Kernel() {
  string os, kernel, version;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> version >> kernel;
  }
  return kernel;
}

// BONUS: Update this to use std::filesystem
vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}


// TODO: Read and return the system memory utilization
float LinuxParser::MemoryUtilization() { 
  string memavailable, memtotal, memfree, buffer;
  string line;
  string value;
  string memoryterm;
  string unit;
  
  std::ifstream filestream(kProcDirectory + kMeminfoFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      linestream >> memoryterm >> value >> unit; 
        if (memoryterm == "MemTotal:") {
          memtotal = value;}
      	if (memoryterm == "MemFree:"){
          memfree = value;}
      	if (memoryterm == "MemAvailable:"){
            memavailable = value; }
        if (memoryterm == "Buffer:"){
        buffer =value;
        }
      
  }
  
    double memtotal_double = atof(memtotal.c_str());
    double memfree_double = atof(memfree.c_str());
    
  return (memtotal_double   - memfree_double)/memtotal_double;
  
    }
}

// TODO: Read and return the system uptime
long LinuxParser::UpTime() { 
  long uptime = 0.0;
  string temp = "0.0";
  string line;
  std::ifstream stream(kProcDirectory + kUptimeFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> temp;
  }
  if (temp == ""){
    return 0;
  }
  else
  {
   uptime = std::stol(temp);
  return uptime;
  }
  
   
}
// TODO: Read and return the number of jiffies for the system
long LinuxParser::Jiffies() { 
  
  return 0; }

// TODO: Read and return the number of active jiffies for a PID
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::ActiveJiffies(int pid[[maybe_unused]]) { return 0; }

// TODO: Read and return the number of active jiffies for the system
long LinuxParser::ActiveJiffies() { return 0; }

// TODO: Read and return the number of idle jiffies for the system
long LinuxParser::IdleJiffies() { return 0; }

// TODO: Read and return CPU utilization
std::vector<std::string> LinuxParser::CpuUtilization() { 
  string user  ,  nice ,  system,  idle,      iowait ,irq  , softirq , steal , guest , guest_nice;
  string line;
  std::ifstream stream(kProcDirectory + kStatFilename);
 
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> user >> nice  >> system >> idle >> iowait >> irq >> softirq >> steal >> guest >>guest_nice;

  }

  // The calculation is  done by simply removing the idle time from the total use time to get the utilization
  // percentage.
  double idle_term1  = atof(idle.c_str());
  
  double user_time = atof(user.c_str());
  double nice_time = atof(nice.c_str());
  double system_time = atof(system.c_str());
  double iowait_time = atof(iowait.c_str());
  double irq_time = atof(irq.c_str());
  double softirq_time = atof(softirq.c_str());
  double steal_time = atof(steal.c_str());
  double guest_time = atof(guest.c_str());
  double guest_nice_time = atof(guest_nice.c_str());

  double cpu_utilization_time = (user_time + nice_time +system_time + iowait_time + irq_time 
    + softirq_time + steal_time + guest_time + guest_nice_time) - idle_term1 ;
  double total_time = user_time + nice_time +system_time + iowait_time + irq_time 
    + softirq_time + steal_time + guest_time + guest_nice_time;
  double cpu_utilization = cpu_utilization_time/total_time;
  
  std::vector<std::string> s ; 
    s.push_back(std::to_string(cpu_utilization));
  
  return s; 



 }

// TODO: Read and return the total number of processes
int LinuxParser::TotalProcesses() { 
  string line;
  string no_of_processes;
  string value;

  std::ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      linestream >> no_of_processes >> value ; 
        if (no_of_processes == "processes") {
          if (value.empty()){
            return 0;
          }
          else
          {
            return   stoi(value); 
          }
          
          
      	
      
  }
   }
   
}
return 0;}
// TODO: Read and return the number of running processes
int LinuxParser::RunningProcesses() { 
  
  string line;
  string running_processes;
  string value;

  std::ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      linestream >> running_processes >> value ; 
        if (running_processes == "procs_running") {
          return   stoi(value);}
      	
      
  }
   }
   return 0;
}
// TODO: Read and return the command associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Command(int pid) { 
  string line;
  string commandline;
  string value;

  std::ifstream filestream(kProcDirectory + std::to_string(pid) + kCmdlineFilename);
  if (filestream.is_open()) {
      std::istringstream linestream(line);
      linestream >> commandline  ; 
        
          return  commandline;
      	
      
  
   }
   

  return "none";}

// TODO: Read and return the memory used by a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Ram(int pid) { 
  string line;
  string Vmsize;
  string value;
  string property;

  std::ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      linestream >> property >> value ; 
        if (Vmsize == "VmSize") {
          if (value.empty()){
            return 0;
          }
          else
          {
            return   value;
          }
          
          
      	
      
  }
   }
   return 0;
}}


// TODO: Read and return the user ID associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Uid(int pid) { 
  string line;
  string UID;
  string value;

  std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatusFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      linestream >> UID >> value ; 
        if (UID == "Uid") {
          if (value.empty()){
            return 0;
          }
          else
          {
            return   value;
          }
          
          
      	
      
  }
   }
   return "0";
}}
  

// TODO: Read and return the user associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::User(int pid) { 
  string line;
  string Username;
  string value;

  std::ifstream filestream(kProcDirectory + kPasswordPath);
  if (filestream.is_open()) {
    
      std::istringstream linestream(line);
      linestream >> Username >> value ; 
    
          return   Username;
      	
      
  }
   return "0";
}
   

// TODO: Read and return the uptime of a process
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::UpTime(int pid) { 
  string line;
  string UID;
  string value;

  

int iterator =1;

  std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      while(linestream >> value){
            if (iterator == 22){
              if (value.empty()){
                return 0;
              }
              else
              {
                double time_in_secs  =stoi(value)/sysconf(_SC_CLK_TCK);
              
              return time_in_secs;
              }
              
              
            }
      }
      
      
  }
   }
   return 0;
}
 
