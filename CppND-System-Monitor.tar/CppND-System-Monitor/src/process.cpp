#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>
#include "linux_parser.h"

#include "process.h"

using std::string;
using std::to_string;
using std::vector;

Process::Process(int pid):process_id(pid){
    
    calculate_cpu_usage(pid);
    calculate_uptime(pid);
    find_command(pid);
    find_ram_usage(pid);
    find_user(pid);
}

// TODO: Return this process's ID
int Process::Pid() { 
    
    return process_id; }

// TODO: Return this process's CPU utilization
float Process::CpuUtilization() { 
    return pid_cpu_usage; }


// TODO: Return the command that generated this process
string Process::Command( ) { 
    return process_command; }


// TODO: Return this process's memory utilization
string Process::Ram() { 
    return processRam; }

// TODO: Return the user (name) that generated this process
string Process::User() { 
    return processUser; }

// TODO: Return the age of this process (in seconds)
long int Process::UpTime() { 
    return process_uptime; }

// TODO: Overload the "less than" comparison operator for Process objects
// REMOVE: [[maybe_unused]] once you define the function
bool Process::operator<(Process const& a[[maybe_unused]]) const { return true; }


// Functions for calculating the unknowns

void Process::calculate_cpu_usage(int pid){
    
// read values from filesystem
  long uptime = LinuxParser::UpTime();
  
  float seconds;
  float total_time;
  int iterator =1;
    string line;
    string value;

    string kUtime, kStime ,kCutime,kCstime, starttime;
  std::ifstream filestream(LinuxParser::kProcDirectory + std::to_string(pid) + LinuxParser::kStatFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      while(linestream >> value){
            if (iterator == 14){
              kUtime = value;
            }
            if (iterator == 15){
                kStime = value;
            }
            if (iterator == 16){
                kCutime = value;
            }
            if (iterator == 17){
                kCstime = value;
            }
            if (iterator == 22){
                starttime = value;
            }
      }
      
      }
}
if (kUtime ==""  || kStime == ""){
    kUtime = "0";
    kStime = "0";
    total_time = stol(kUtime) + stol(kStime);
}
else
{
    total_time = stol(kUtime) + stol(kStime);
}

if (kCutime =="" || kCstime == "")
{
    kCutime = "0";
    kCstime = "0";
    total_time = total_time + stol(kCutime) + stol(kCstime);
}
else
{
    total_time = total_time + stol(kCutime) + stol(kCstime);
}



if (starttime.empty()){
    seconds = uptime - 0.0;
}
else
{
    seconds = uptime - (stod(starttime)/sysconf(_SC_CLK_TCK));
}


pid_cpu_usage = 100* ((total_time/sysconf(_SC_CLK_TCK)  )/seconds );

}

void Process::calculate_uptime(int pid){
    process_uptime = LinuxParser::UpTime(pid);
}

void Process::find_command(int pid){
    process_command =  LinuxParser::Command(pid);
}

void Process::find_ram_usage(int pid){
    processRam = LinuxParser::Ram(pid);
}

void  Process::find_user(int pid){
    processUser = LinuxParser::User(pid);
}





