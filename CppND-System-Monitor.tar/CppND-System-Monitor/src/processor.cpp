#include "processor.h"
#include "linux_parser.h"
#include "stdlib.h"
#include "vector"
#include "string"

#include <dirent.h>
#include <unistd.h>

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() {  

s = LinuxParser::CpuUtilization(); 

  double utilization  = atof(s[0].c_str());
  
return utilization; }