#ifndef PROCESS_H
#define PROCESS_H

#include <string>

/*
Basic class for Process representation
It contains relevant attributes as shown below
*/
class Process {
 public:
  Process(int pid);
  
  int Pid();                               // TODO: See src/process.cpp
  std::string User();                      // TODO: See src/process.cpp
  std::string Command();                   // TODO: See src/process.cpp
  float CpuUtilization();                  // TODO: See src/process.cpp
  std::string Ram();                       // TODO: See src/process.cpp
  long int UpTime();                       // TODO: See src/process.cpp
  bool operator<(Process const& a) const;  // TODO: See src/process.cpp


  // TODO: Declare any necessary private members
 private:
 void calculate_cpu_usage(int pid);
 void calculate_uptime(int pid);
 void find_command(int pid);
 void find_ram_usage(int pid);
 void find_user(int pid);
 

float pid_cpu_usage;
int process_id;
std::string process_command;
std::string processRam;
std::string processUser;
long int process_uptime;

};

#endif